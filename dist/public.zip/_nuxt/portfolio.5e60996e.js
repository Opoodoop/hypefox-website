import{a as o}from"./entry.b427b019.js";const n=o({__name:"portfolio",setup(e){return()=>{}}});export{n as default};
