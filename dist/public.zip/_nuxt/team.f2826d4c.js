import{a as e}from"./entry.b427b019.js";const n=e({__name:"team",setup(t){return()=>{}}});export{n as default};
