import{a as e}from"./entry.b427b019.js";const a=e({__name:"about",setup(o){return()=>{}}});export{a as default};
