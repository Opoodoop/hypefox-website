import{a as e}from"./entry.b427b019.js";const t=e({__name:"index",setup(n){return()=>{}}});export{t as default};
